package Variable

fun main() {

//    val/var nama variable :String =value

    val Nama:String
    Nama = "Arief Hidayat"

    val nama="Arief HIdayat"
    print("Variable.getNama saya $nama dan nama anda adalah $Nama")

}