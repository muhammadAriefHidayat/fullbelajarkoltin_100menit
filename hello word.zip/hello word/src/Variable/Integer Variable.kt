package Variable

fun main() {
/**
 * ciri variable integer adalah angka dengan bilangan bulat
 * integer adalah variable bertipe angka
 * Val adalah cara pendeklarasian Variable yang immutable,
 * */
    val Age = 24
//    Age = 35
    
    val myAge : Int = 43

    val myName = "Arief Hidayat"

    var Umur = 25
    Umur = 30
    println(Umur)


    println("myname is $myName and my age is $myAge")
    print("nama saya adalah "+ myName +" dan umur saya" + myAge)

}