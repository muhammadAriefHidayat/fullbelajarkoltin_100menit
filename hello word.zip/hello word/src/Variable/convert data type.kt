package Variable

fun main() {
    /**
     * convert data type form integer to string or float and how to operating them
     * */

    //deklarasi variable
    var angkaPertama : Int = 10
    var masukkanAngka = 13.0

    //konvert type data to int
    angkaPertama = masukkanAngka.toInt()

//    cetak hasil
    println(angkaPertama.toFloat() + 122)
}