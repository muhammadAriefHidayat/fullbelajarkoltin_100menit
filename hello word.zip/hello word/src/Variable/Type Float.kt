package Variable

fun main() {
    /**
     * ciri variable float memiliki huruf f dibelakang angka
     * variable type float dan double adalah variable dengan nilai desimal
     * */
    val uangsaku:Float
    uangsaku = 30.6f

    val uangjajan:Double
    uangjajan=30.0

    println("uangsaku = $uangsaku dan uang jajan = $uangjajan")
}

