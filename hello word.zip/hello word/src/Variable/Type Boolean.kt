package Variable

fun main() {
    /**
     * Variable type boolean adalah variable yang hanya memiliki dua nilai saja, yaitu true dan false
     * */

    val kebenaran :Boolean
    kebenaran = true

    var kesalahan = false
    print("$kebenaran dan $kesalahan")

}