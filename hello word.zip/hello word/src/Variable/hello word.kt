package Variable

fun main() {


    /*
    commntar pada kotlin
    dfdsf
    asdfa
    adfa
    afds
    */
    print(" i love kotlin")

    //     ctrl + /

    /*
    assalamualaikum
    selamat datang di arief hidayat
    tutorial pemrograman
     */

    /*
    / + * enter
     */

    /*
    * bedanya
    * setiap bari terdapat bintang di awal kalimat
    * */
//    ctrl +/ enter

    /**
     * ctrl + shift * trus Fungsi.tambah bintang lagi
     * setelah itu dienter
     * */

}