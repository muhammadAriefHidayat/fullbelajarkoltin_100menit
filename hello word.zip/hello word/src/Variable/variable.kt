package Variable

fun main(args: Array<String>) {

    /**
     * perbedaan antara val dan var
     * Kesimpu(tetaplannya val adalah cara mendeklarasikan variable yang mutabel /konstan/tidak bisa dirubah)
     * sedangkan var sebaliknya yaitu value bisa dirubah
     * */

//deklarasi variable dengan var
    val lastName = "muhammad"

    val nama:String = "arief hidayat"



    val alamat = "Indonesia"


    print("nama saya adalah $lastName $nama dan  alamat saya di $alamat")
}
