package Variable

fun main() {
    /**
     * variabel type char adalah variable dengan nilai karakter
     * */

    val karakter:Char
    karakter = '8'

    val huruf = 'a'

    print("huruf $huruf dan krakter $karakter")
}