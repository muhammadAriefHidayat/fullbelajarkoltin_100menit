package PemrogramanStruktur

fun main() {
    /**
     * if else statement???
     * mirip seperti percabangan dalam memilih pilihan
     * */

//    kita deklarasikan sebuah variable
    val nomorPertama = 8
    val nomorKedua = 10

//    if (nomorpertama > nomorkedua){
//        print("yesss")
//    }else{
//        print("salah")
//    }

//    melakukan percabangan if else dengan satu baris
    if (nomorKedua > nomorPertama) print("noooo") else print("yesss")
}
