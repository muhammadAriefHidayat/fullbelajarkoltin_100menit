package PemrogramanStruktur

fun main() {
    /**
     *apa itu kondisional operator????
     *konditional operator memiliki nilai pengembalian boolean
     * >
     * <
     * ==
     * !=
     * >=
     * <=
     **/

    //deklarasi variable
    val nilaipertama = 10
    val nilaikedua  = 8

    //mencetak hasil dari kondisional operator
    println(nilaipertama < nilaikedua)
    println(nilaipertama > nilaikedua)
    println(nilaipertama == nilaikedua)
    println(nilaipertama != nilaikedua)
    println(nilaipertama <= nilaikedua)
    println(nilaipertama >= nilaikedua)
}