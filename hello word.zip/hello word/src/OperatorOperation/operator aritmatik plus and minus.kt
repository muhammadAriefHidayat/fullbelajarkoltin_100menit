package OperatorOperation

fun main() {
    /**
     * operator aritmatika
     * + - * / %
     * */

//    deklarasi variable
    val kueArief = 8
    val kueHidayat = 10

//    mencetak nilai penjumlahan dan pengurangan
    println("${kueArief + kueHidayat}")
    println(kueArief - kueHidayat)

}