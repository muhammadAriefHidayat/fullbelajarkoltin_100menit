package OperatorOperation

fun main() {
    /**
     * increamenting and decrementing
     * ?????
     * increment adalah menambahkan satu angka pada value sebelumnya
     * decrement adalah menurunkan satu angka pada value sebelumnya
     * ++  /  --
     * */

//    deklarasi variable
    var angkaAwal = 10

//   decrement pada variable hasil
    val hasil  = angkaAwal --
    println(hasil)
    println(angkaAwal)
}