package OperatorOperation

fun main() {
    /**
     * apa itu readline
     * Readline adalah input pada kotlin yang digunakan untuk menyimpan value pada variabel
     * menggunakan input keyboaed
     * */

    println("siapa nama kamu...???")

//    menginput user dengan input keyborad (readline)
    val user:String? = readLine()
    println("nama kamu adalah $user")


}