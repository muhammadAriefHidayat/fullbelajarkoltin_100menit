package OperatorOperation

fun main() {
    /**
     * apa itu remainder..?????
     * */

//    modulus
//    remanider adalah sisa hasil bagi antara dua variable
//    5 % 2 = 1  4/2 = 2 4%2????= 0
    var nomorpertama = 8
    val nomorkedua = 3

    println("hasil dari remainder atau modulus antara $nomorpertama dan $nomorkedua adalah ${nomorpertama % nomorkedua}")
    println(nomorpertama)
}
